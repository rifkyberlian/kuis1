<?php
define("DB_HOST","localhost");
define("DB_USER","berlian");
define("DB_PASSWORD","densus090912");
define("DB_NAME","berliandatabase");

// echo DB_HOST;
